<?php

?>

<!DOCTYPE html>
<html>
	<head>
<meta charset = "UTF-8">
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
