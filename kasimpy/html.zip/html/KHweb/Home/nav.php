<body id="body">
	<nav class="mainNav">
		<a class="active" href="index.html">Home</a>
      <a href="Navigations.html">Navigation</a>
      <a href="search.html">Search</a>
      <a href="todo.html">Checkboxes</a>
      <a href="flexboxBox.html">boxes</a>
      <a href="grid.html">Grid</a>
      <a href="navExperiment.html">Experimental nav</a>
      <a href="unwanted.html">Another page</a>
      <a href="https://www.w3schools.com/whatis/default.asp">Roadmap</a>
    </nav>
