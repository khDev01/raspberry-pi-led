<?php include "head.php"; ?>



<a href="newpageTest.html">Next page</a>
<br>
<a href="/KHweb/Home/index.php">Next page</a>

</body>
</html>
