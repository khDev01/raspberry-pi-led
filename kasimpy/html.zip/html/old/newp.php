<!DOCTYPE html>
<html>
<head>
<meta charset = "UTF-8">
<title>Welcome index.php</title>
<link rel="stylesheet" type="text/css" href="styles.css"/>

</head>

<body>
<a href="/HowTo/index.html">New Pages<a>
<h1>First web</h1>
<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam pellentesq$
 nunc efficitur molestie auctor, elit massa fermentum dolor, et aliquam
nunc elit sed nisi. Suspendisse ex enim, consequat a elit eget, facilis$
 varius ligula. Cras eu varius est. Pellentesque suscipit orci quis dia$
euismod dictum. Class aptent taciti sociosqu ad litora torquent per con$
 nostra, per inceptos himenaeos. Aliquam accumsan dapibus malesuada. Ut
 maximus semper arcu ultrices tempor. Phasellus fringilla, orci eu dign$
sim dignissim, felis risus semper tellus, in feugiat lectus lectus grav$
elit. Pellentesque habitant morbi tristique senectus et netus et malesu$
fames ac turpis egestas. Cras accumsan sapien neque, et ullamcorper vel$
 congue eget
</p>
